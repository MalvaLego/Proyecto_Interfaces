using System.Windows.Input;

namespace Proyecto.ViewModels
{
    public class SesionVM : ContentPage
    {


        public ICommand LoginCommand { get; set; }

        public SesionVM()
        {
            LoginCommand = new Command(Login);
        }

        async void Login()
        {
            await Shell.Current.GoToAsync($"MainPage");
        }
    }
}

