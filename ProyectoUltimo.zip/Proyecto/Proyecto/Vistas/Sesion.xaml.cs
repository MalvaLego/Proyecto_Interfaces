namespace Proyecto.Vistas;

public partial class Sesion : ContentPage
{
	public Sesion()
	{
		InitializeComponent();
	}
}