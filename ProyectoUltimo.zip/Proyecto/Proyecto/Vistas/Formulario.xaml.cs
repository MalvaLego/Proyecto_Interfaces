namespace Proyecto.Vistas;

public partial class Formulario : ContentPage
{
	public Formulario()
	{
		InitializeComponent();
	}
}