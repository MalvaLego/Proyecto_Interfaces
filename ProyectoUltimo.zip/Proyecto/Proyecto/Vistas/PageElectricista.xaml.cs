﻿using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows.Input;

namespace Proyecto.Vistas { 

    public partial class PageElectricista : ContentPage
    {
        public ObservableCollection<string> Servicios { get; set; }
        public ICommand goPageCommand { get; set; }
        public PageElectricista()
        {
            InitializeComponent();
            goPageCommand = new Command(goPage);

            Servicios = new ObservableCollection<string>
                {
                    "🔧 Instalación eléctrica",
                    "⚡ Reparación de cortocircuitos",
                    "🔍 Revisión de paneles eléctricos",
                    "🔦 Solución de fallos eléctricos",
                    "🚨 Instalación de sistemas de alarma",
                    "🛠️ Reparación de electrodomésticos",
                    "🔌 Instalación de enchufes y tomas de corriente",
                };

            BindingContext = this;
        }

        private async void OnSalirClicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }

        async void goPage()
        {
            Debug.WriteLine("Entró");
            await Shell.Current.GoToAsync($"Formulario");
        }
    }

}