﻿using System.Collections.ObjectModel;

namespace Proyecto.Vistas;

public partial class PageFontaneria : ContentPage
{
    public ObservableCollection<string> Servicios { get; set; }
    public PageFontaneria()
	{
		InitializeComponent();

        Servicios = new ObservableCollection<string>
        {
            "🔑 Apertura de puertas sin llave",
            "🚪 Cambio e instalación de cerraduras",
            "🚗 Duplicado de llaves para autos",
            "🚗 Abrir puertas de coche",
            "🔐 Instalación de cerraduras de alta seguridad",
            "📦 Apertura de cajas fuertes",
            "🛎️ Instalación de cerraduras electrónicas",
            "🧰 Cambio de combinación en cerraduras",
            "🔓 Extracción de llaves rotas",
            "🏢 Sistemas de control de acceso",
            "🛡️ Blindaje de puertas"
        };

        BindingContext = this;
    }

    private async void OnSalirClicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }
}