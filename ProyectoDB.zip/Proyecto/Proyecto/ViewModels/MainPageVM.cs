using Proyecto.Vistas;
using System.Windows.Input;

namespace Proyecto.ViewModels
{

    public class MainPageVM : ContentPage
    {
        public ICommand fontaneriaCommand { get; set; }
        public ICommand electricistaCommand { get; set; }
        public ICommand cerrajeriaCommand { get; set; }
        public ICommand jardineriaCommand { get; set; }

        public ICommand ListaServiciosCommand { get; set; }
        public ICommand RegresarCommand { get; set; }
        public MainPageVM()
        {
           
            fontaneriaCommand = new Command(pagFontaneria);
            electricistaCommand = new Command(pagElectricista);
            cerrajeriaCommand = new Command(pagCerrajeria);
            jardineriaCommand = new Command(pagJardineria);
            ListaServiciosCommand = new Command(listaServicios);
            RegresarCommand = new Command(Regresar);
            BindingContext = this;
        }

        async void pagFontaneria()
        {
            await Shell.Current.GoToAsync($"PageFontaneria");
        }

        async void pagElectricista()
        {
            await Shell.Current.GoToAsync($"PageElectricista");
        }

        async void pagJardineria()
        {
            await Shell.Current.GoToAsync($"PageJardineria");
        }

        async void pagCerrajeria()
        {
            await Shell.Current.GoToAsync($"PageCerrajeria");
        }

        async void listaServicios()
        {
            await Shell.Current.GoToAsync($"ListaServicios");
        }

        async void Regresar()
        {
            //await Shell.Current.GoToAsync($"Sesion");
        }

        private void OnPointerEntered(object sender, EventArgs e)
        {
            if (sender is Frame frame)
            {
                frame.Scale = 1.1;
                frame.Opacity = 0.7;
            }
        }

        private void OnPointerExited(object sender, EventArgs e)
        {
            if (sender is Frame frame)
            {
                frame.Scale = 1;
                frame.Opacity = 1;
            }
        }
    }
}

