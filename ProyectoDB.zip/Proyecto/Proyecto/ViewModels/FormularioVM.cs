using System.Windows.Input;
using SQLite;
using Proyecto.Models;

namespace Proyecto.ViewModels {
    [QueryProperty(nameof(StringServicio), "servicio")]
	public class FormularioVM : ContentPage
	{
        string ruta;
        private string _servicio;
        private string _nombre;
        private string _direccion;
        private string _telefono;
        private string _descripcion;
        private string _urgencia;

        public string StringServicio
        {
            set {
                _servicio = value;
                _servicio = _servicio.Substring(2);
                OnPropertyChanged(); 
            }
            get {
                return "Servicio selecionado : " + _servicio; 
            }
        }

        public string Nombre
        {
            get => _nombre;
            set
            {
                _nombre = value;
                OnPropertyChanged();
            }
        }
        
        public string Direccion
        {
            get => _direccion;
            set
            {
                _direccion = value;
                OnPropertyChanged();
            }
        }

        public string Telefono
        {
            get => _telefono;
            set
            {
                _telefono = value;
                OnPropertyChanged();
            }
        }
        
        public string Descripcion
        {
            get => _descripcion;
            set
            {
                _descripcion = value;
                OnPropertyChanged();
            }
        }

        public String Urgencia
        {
            get => _urgencia;
            set
            {
                _urgencia = value;
                OnPropertyChanged();
            }
        }

        public ICommand finalizarCommand { get; set; }
        public FormularioVM()
		{
            finalizarCommand = new Command(finalizar);
            BindingContext = this;
        }

        async void finalizar()
        {
            if (string.IsNullOrWhiteSpace(Direccion) || string.IsNullOrWhiteSpace(Nombre))
            {
                await Shell.Current.DisplayAlert("ERROR", "Para pasar al formulario debes escribir la direcci�n", "OK");
                return;
            }
            guardarEnDB();
            await Shell.Current.GoToAsync($"Final");
        }

        async void guardarEnDB()
        {
            string baseDirectory = AppContext.BaseDirectory;
            string databasePath = Path.Combine(baseDirectory, "DB", "ProyectoDB.db");

            //await Shell.Current.DisplayAlert("OK", $"Ruta de la base de datos {databasePath}", "Ok");

            try
            {
                // Llama a crearTablaSiNoExiste para asegurarte de que la tabla est� presente
                crearTablaSiNoExiste();

                using (var connection = new SQLiteConnection(databasePath))
                {
                    // Inserta una nueva fila en la tabla Servicios
                    var nuevoServicio = new Servicio
                    {
                        Cliente = Nombre,
                        TipoServicio = _servicio,
                        Direccion = Direccion,
                        Telefono = Telefono,
                        Descripcion = Descripcion,
                        Urgencia = Urgencia
                    };

                    // Verifica si la inserci�n fue exitosa
                    int filasAfectadas = connection.Insert(nuevoServicio); // Inserta el objeto en la tabla
                    await Shell.Current.DisplayAlert("OK", $"Se ha registrado {filasAfectadas} campo", "Ok");
                }
            }
            catch (SQLiteException ex)
            {
                // Mostrar un mensaje con el error
                Console.WriteLine($"Error de base de datos: {ex.Message}");
                Shell.Current.DisplayAlert("Error", $"Error de base de datos: {ex.Message}", "OK");
            }
            catch (Exception ex)
            {
                // Mostrar un mensaje con el error general
                Console.WriteLine($"Ocurri� un error: {ex.Message}");
                Shell.Current.DisplayAlert("Error", $"Ocurri� un error: {ex.Message}", "OK");
            }
        }

        void crearTablaSiNoExiste()
        {
            string baseDirectory = AppContext.BaseDirectory;
            string databasePath = Path.Combine(baseDirectory, "DB", "ProyectoDB.db");

            using (var connection = new SQLiteConnection(databasePath))
            {
                // Verifica si la tabla ya existe
                var tablaExistente = connection.Table<Servicio>().FirstOrDefault();
                if (tablaExistente == null)
                {
                    // Si no existe, crea la tabla
                    connection.CreateTable<Servicio>();
                    Console.WriteLine("Tabla creada correctamente.");
                }
                else
                {
                    Console.WriteLine("La tabla ya existe.");
                }
            }
        }

    }
}