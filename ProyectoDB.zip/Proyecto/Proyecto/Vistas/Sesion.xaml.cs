using Proyecto.ViewModels;
using System.Windows.Input;
namespace Proyecto.Vistas;

public partial class Sesion : ContentPage
{
	public Sesion()
	{
		InitializeComponent();
		BindingContext = new SesionVM();
	}

}