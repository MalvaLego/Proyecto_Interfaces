﻿using System.Windows.Input;
using Proyecto.Vistas;

namespace Proyecto
{
    public partial class MainPage : ContentPage
    {
        public ICommand fontaneriaCommand { get; set; }
        public ICommand electricistaCommand { get; set; }
        public ICommand cerrajeriaCommand { get; set; }
        public ICommand jardineriaCommand { get; set; }
        public MainPage()
        {
            InitializeComponent();
            fontaneriaCommand = new Command(pagFontaneria);
            electricistaCommand = new Command(pagElectricista);
            cerrajeriaCommand = new Command(pagCerrajeria);
            jardineriaCommand = new Command(pagJardineria);

            BindingContext = this;
        }

        async void pagFontaneria()
        {
            await Shell.Current.GoToAsync($"PageFontaneria");
        }

        async void pagElectricista() 
        {
            await Shell.Current.GoToAsync($"PageElectricista");
        }

        async void pagJardineria()
        {
            await Shell.Current.GoToAsync($"PageJardineria");
        }

        async void pagCerrajeria()
        {
            await Shell.Current.GoToAsync($"PageCerrajeria");
        }

        private void OnPointerEntered(object sender, EventArgs e)
        {
            if (sender is Frame frame)
            {
                frame.Scale = 1.1;
                frame.Opacity = 0.7;
            }
        }

        private void OnPointerExited(object sender, EventArgs e)
        {
            if (sender is Frame frame)
            {
                frame.Scale = 1;
                frame.Opacity = 1;
            }
        }
    }

}
