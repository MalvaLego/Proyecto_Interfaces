﻿using System.Windows.Input;
using Proyecto.Vistas;

namespace Proyecto
{
    public partial class MainPage : ContentPage
    {
        public ICommand fontaneriaCommand { get; set; }
        public ICommand electricistaCommand { get; set; }
        public ICommand cerrajeriaCommand { get; set; }
        public ICommand jardineriaCommand { get; set; }
        public MainPage()
        {
            InitializeComponent();
            fontaneriaCommand = new Command(pagFontaneria);
            electricistaCommand = new Command(pagElectricista);
            cerrajeriaCommand = new Command(pagCerrajeria);
            jardineriaCommand = new Command(pagJardineria);

            BindingContext = this;
        }

        async void pagFontaneria()
        {
            await Shell.Current.GoToAsync($"PageFontaneria");
        }

        async void pagElectricista() 
        {
            await Shell.Current.GoToAsync($"PageElectricista");
        }

        async void pagJardineria()
        {
            await Shell.Current.GoToAsync($"PageJardineria");
        }

        async void pagCerrajeria()
        {
            await Shell.Current.GoToAsync($"PageCerrajeria");
        }

        private async void OnPointerEntered(object sender, EventArgs e)
        {
            if (sender is ImageButton imageButton)
            {
                await imageButton.ScaleTo(1.2, 150, Easing.CubicInOut); // Aumenta el tamaño
                await imageButton.FadeTo(0.7, 150, Easing.CubicInOut);  // Reduce la opacidad
            }
        }

        private async void OnPointerExited(object sender, EventArgs e)
        {
            if (sender is ImageButton imageButton)
            {
                await imageButton.ScaleTo(1, 150, Easing.CubicInOut); // Vuelve al tamaño normal
                await imageButton.FadeTo(1, 150, Easing.CubicInOut);  // Restaura la opacidad
            }
        }
    }

}
