﻿using Proyecto.Vistas;

namespace Proyecto
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
            Routing.RegisterRoute(nameof(MainPage), typeof(Proyecto.Vistas.MainPage));
            Routing.RegisterRoute(nameof(PageCerrajeria), typeof(PageCerrajeria));
            Routing.RegisterRoute(nameof(PageElectricista), typeof(PageElectricista));
            Routing.RegisterRoute(nameof(PageFontaneria), typeof(PageFontaneria));
            Routing.RegisterRoute(nameof(PageJardineria), typeof(PageJardineria));
            Routing.RegisterRoute(nameof(Sesion), typeof(Sesion));
            Routing.RegisterRoute(nameof(Formulario), typeof(Formulario));
            Routing.RegisterRoute(nameof(Final), typeof(Final));
        }
    }
}
