using System.Windows.Input;

namespace Proyecto.ViewModels { 

	public class FormularioVM : ContentPage
	{
        private string _nombre;
        public string Nombre
        {
            get => _nombre;
            set
            {
                _nombre = value;
                OnPropertyChanged();
            }
        }
        private string _direccion;
        public string Direccion
        {
            get => _direccion;
            set
            {
                _direccion = value;
                OnPropertyChanged();
            }
        }
        private string _descripcion;
        public string Descripcion
        {
            get => _descripcion;
            set
            {
                _descripcion = value;
                OnPropertyChanged();
            }
        }

        public ICommand finalizarCommand { get; set; }
        public FormularioVM()
		{
            finalizarCommand = new Command(finalizar);
        }

        async void finalizar()
        {
            if (string.IsNullOrWhiteSpace(Direccion))
            {
                await Shell.Current.DisplayAlert("ERROR", "Para pasar al formulario debes escribir la direcci�n", "OK");
                return;
            }

            await Shell.Current.GoToAsync($"Final");
        }

    }
}