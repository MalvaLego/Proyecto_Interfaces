
using System.Windows.Input;

namespace Proyecto.ViewModels { 

	public class FormularioVM : ContentPage
	{

        public ICommand finalizarCommand { get; set; }
        

        
        public FormularioVM()
		{
            finalizarCommand = new Command(finalizar);
        }



        async void finalizar()
        {
            await Shell.Current.GoToAsync($"Final");
        }


    }

}