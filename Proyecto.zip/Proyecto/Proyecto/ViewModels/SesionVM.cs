﻿using System.Windows.Input;
using System;
using Microsoft.Maui.Controls;
using Firebase.Auth;
using Firebase.Auth.Providers;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Java.Security;

namespace Proyecto.ViewModels
{
    public class SesionVM : INotifyPropertyChanged
    {

        private string _correo;
        public string Correo
        {
            get => _correo;
            set
            {
                _correo = value;
                OnPropertyChanged();
            }
        }

        private string _contra;
        public string Contra
        {
            get => _contra;
            set
            {
                _contra = value;
                OnPropertyChanged();
            }
        }

        private string apiKey = "AIzaSyBuBjYulxLtsXcZ4_FD3Fu1c9WGTbeURBI"; // 🔹 Reemplaza con tu API Key de Firebase
        private FirebaseAuthProvider _authProvider;
        public ICommand LoginCommand { get; set; }

        public SesionVM()
        {
            //_authProvider = new FirebaseAuthProvider(new FirebaseConfig(apiKey));

            LoginCommand = new Command(Login);
        }

        async void Login()
        {

            

            await Shell.Current.GoToAsync($"MainPage");
        }


        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}

