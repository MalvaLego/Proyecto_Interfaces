using System.Collections.ObjectModel;

namespace Proyecto.ViewModels { 

	public class RegisterVM : ContentPage
	{


		

		public RegisterVM()
		{
			
			
		}
	}
}