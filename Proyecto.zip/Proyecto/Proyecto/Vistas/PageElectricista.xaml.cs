namespace Proyecto.Vistas;

public partial class PageElectricista : ContentPage
{
	public PageElectricista()
	{
		InitializeComponent();
	}
}