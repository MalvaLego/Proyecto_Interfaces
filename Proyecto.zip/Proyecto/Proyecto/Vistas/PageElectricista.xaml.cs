﻿using System.Collections.ObjectModel;

namespace Proyecto.Vistas;

public partial class PageElectricista : ContentPage
{
    public ObservableCollection<string> Servicios { get; set; }

    public PageElectricista()
    {
        InitializeComponent();

        Servicios = new ObservableCollection<string>
            {
                "🔧 Instalación eléctrica",
                "⚡ Reparación de cortocircuitos",
                "🔍 Revisión de paneles eléctricos",
                "🔦 Solución de fallos eléctricos",
                "🚨 Instalación de sistemas de alarma",
                "🛠️ Reparación de electrodomésticos",
                "🔌 Instalación de enchufes y tomas de corriente",
            };

        BindingContext = this;
    }

    private async void OnSalirClicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private void OnServicioSeleccionado(object sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.Count > 0)
        {
            var servicioSeleccionado = e.CurrentSelection[0] as string; 
        }
    }

}