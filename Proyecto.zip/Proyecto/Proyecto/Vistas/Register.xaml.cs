namespace Proyecto.Vistas;

public partial class Register : ContentPage
{
	public Register()
	{
		InitializeComponent();
	}
}