namespace Proyecto.Vistas;

public partial class PageFontaneria : ContentPage
{
	public PageFontaneria()
	{
		InitializeComponent();
	}
}