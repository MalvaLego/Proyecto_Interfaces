﻿using System.Collections.ObjectModel;

namespace Proyecto.Vistas;

public partial class PageFontaneria : ContentPage
{
    public ObservableCollection<string> Servicios { get; set; }
    string servicio;
    public PageFontaneria()
	{
		InitializeComponent();

        Servicios = new ObservableCollection<string>
        {
            "🚰 Instalación y reparación de tuberías",
            "🚽 Reparación de fugas de agua",
            "🔧 Destape de cañerías y desagües",
            "🚿 Instalación de calentadores de agua",
            "🛁 Instalación y reparación de grifos",
            "🛠️ Mantenimiento de sistemas de agua potable",
            "🌊 Reparación de filtraciones en techos",
            "🚰 Instalación de sistemas de riego",
            "💧 Tratamiento y purificación de agua",
            "🏠 Revisión y mantenimiento de plomería en el hogar"
        };


        BindingContext = this;
    }

    private async void OnSalirClicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private async void OnFormularioClicked(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(servicio))
        {
            await DisplayAlert("ERROR", "Para pasar al formulario primero debes de seleccionar el servicio deseado.", "OK");
            return;
        }
        await Shell.Current.GoToAsync($"Formulario?servicio={servicio}");
    }

    private void OnServicioSeleccionado(object sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.Count > 0)
        {
            var servicioSeleccionado = e.CurrentSelection[0] as string;
            servicio = servicioSeleccionado;
        }
    }
}