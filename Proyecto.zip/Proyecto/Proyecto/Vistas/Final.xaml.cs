namespace Proyecto.Vistas;

public partial class Final : ContentPage
{
	public Final()
	{
		InitializeComponent();
	}
}