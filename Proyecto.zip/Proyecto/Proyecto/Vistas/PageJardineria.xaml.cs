﻿using System.Collections.ObjectModel;

namespace Proyecto.Vistas;

public partial class PageJardineria : ContentPage
{
    public ObservableCollection<string> Servicios { get; set; }
    public PageJardineria()
	{
		InitializeComponent();

        Servicios = new ObservableCollection<string>
        {
            "🌱 Diseño y mantenimiento de jardines",
            "✂️ Poda de árboles y arbustos",
            "💧 Instalación de sistemas de riego",
            "🌿 Control de plagas y enfermedades",
            "🏡 Decoración con plantas y paisajismo",
            "🍃 Limpieza y recolección de hojas",
            "🌻 Siembra y fertilización de plantas",
            "🏗️ Construcción de áreas verdes",
            "🔆 Instalación de iluminación para jardines",
            "🌳 Tala y trasplante de árboles"
        };

        BindingContext = this;
    }

    private void OnServicioSeleccionado(object sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.Count > 0)
        {
            var servicioSeleccionado = e.CurrentSelection[0] as string;
        }
    }
}