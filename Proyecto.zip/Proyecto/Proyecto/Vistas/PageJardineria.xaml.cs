﻿using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows.Input;

namespace Proyecto.Vistas
{
    public partial class PageJardineria : ContentPage
    {
        public ObservableCollection<string> Servicios { get; set; }
        public ICommand goPageCommand { get; set; }
        string servicio;
        public PageJardineria()
        {
            InitializeComponent();
            goPageCommand = new Command(goPage);

            Servicios = new ObservableCollection<string>
                {
                    "🌱 Mantenimiento de jardines",
                    "🌳 Podado de árboles",
                    "🌾 Corte de césped",
                    "🍃 Poda de arbustos y setos",
                    "🌸 Diseño y decoración de jardines",
                    "🏡 Instalación de riego automático",
                    "🌷 Instalación de césped artificial",
                    "🌻 Eliminación de malas hierbas",
                    "🌳 Plantación de árboles ornamentales",
                    "🏵️ Cuidado de plantas de interior",
                };

            BindingContext = this;
        }

        private async void OnSalirClicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }

        async void goPage()
        {
            await Shell.Current.GoToAsync($"Formulario");
        }

        private void Button_Clicked(object sender, EventArgs e)
        {

        }

        private void OnServicioSeleccionado(object sender, SelectionChangedEventArgs e)
        {
            if (e.CurrentSelection.Count > 0)
            {
                /*string servicioSeleccionado = e.CurrentSelection[0] as string;
                servicio =servicioSeleccionado;*/

                servicio = e.CurrentSelection[0] as string;
                
            }
        }

        private async void OnFormularioClicked(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(servicio))
            {
                await DisplayAlert("ERROR", "Para pasar al formulario primero debes de seleccionar el servicio deseado.", "OK");
                return;
            }
            await Shell.Current.GoToAsync($"Formulario?servicio={servicio}");
        }
    }

}