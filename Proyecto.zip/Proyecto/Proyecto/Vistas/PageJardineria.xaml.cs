namespace Proyecto.Vistas;

public partial class PageJardineria : ContentPage
{
	public PageJardineria()
	{
		InitializeComponent();
	}
}