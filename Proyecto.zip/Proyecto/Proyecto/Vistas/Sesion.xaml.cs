using System.Windows.Input;

namespace Proyecto.Vistas;

public partial class Sesion : ContentPage
{
	public ICommand irCommand {  get; set; }
	public Sesion()
	{
		InitializeComponent();
		irCommand = new Command(ir);
		BindingContext = this;
	}

	async void ir()
	{
		await Shell.Current.GoToAsync($"login");
	}
}