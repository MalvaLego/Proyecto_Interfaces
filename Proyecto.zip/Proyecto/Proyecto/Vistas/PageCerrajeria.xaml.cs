namespace Proyecto.Vistas;

public partial class PageCerrajeria : ContentPage
{
	public PageCerrajeria()
	{
		InitializeComponent();
	}
}