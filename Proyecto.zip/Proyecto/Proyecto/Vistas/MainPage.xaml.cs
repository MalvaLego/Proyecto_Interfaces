﻿using System.Windows.Input;
using Proyecto.Vistas;

using Proyecto.ViewModels;

namespace Proyecto.Vistas
{
    public partial class MainPage : ContentPage
    {
        
        public MainPage()
        {
            InitializeComponent();
            BindingContext = new MainPageVM();
        }

        
    }

}
