namespace Proyecto.Vistas;
[QueryProperty(nameof(Servicio), "servicio")]
public partial class Formulario : ContentPage
{
    private string _servicio;
    public string Servicio
    {
        get => _servicio;
        set
        {
            _servicio = value;
            OnPropertyChanged(nameof(Servicio));
        }
    }

    public Formulario()
    {
        InitializeComponent();
        BindingContext = this;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        lblServicio.Text = "Servicio seleccionado: " + Servicio;
    }
}