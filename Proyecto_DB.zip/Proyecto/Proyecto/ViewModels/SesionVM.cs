﻿using System.Windows.Input;
using System;
using Microsoft.Maui.Controls;
using Firebase.Auth;
using Firebase.Auth.Providers;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Proyecto.ViewModels
{
    public class SesionVM : INotifyPropertyChanged
    {

        private string _correo;
        public string Correo
        {
            get => _correo;
            set
            {
                _correo = value;
                OnPropertyChanged();
            }
        }

        private string _contra;
        public string Contra
        {
            get => _contra;
            set
            {
                _contra = value;
                OnPropertyChanged();
            }
        }

        public ICommand LoginCommand { get; set; }
        public ICommand irCommand { get; set; }

        public SesionVM()
        {
            LoginCommand = new Command(Login);
            irCommand = new Command(ir);
        }

        async void Login()
        {
            if(string.IsNullOrWhiteSpace(Correo) || string.IsNullOrWhiteSpace(Contra)){
                await Shell.Current.DisplayAlert("ERROR", "Debes de rellenar los campos solicitados", "Ok");
                return;
            }
            await Shell.Current.GoToAsync($"MainPage");
        }

        async void ir()
        {
            await Shell.Current.GoToAsync($"login");
        }


        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}

