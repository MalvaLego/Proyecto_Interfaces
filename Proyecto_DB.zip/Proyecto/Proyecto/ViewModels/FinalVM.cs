using System.Windows.Input;

namespace Proyecto.ViewModels { 

    public class FinalVM : ContentPage
    {

        public ICommand RegresarCommand { get; set; }

        public FinalVM()
	    {
            RegresarCommand = new Command(Regresar);
        }

   
        async void Regresar()
        {
            await Shell.Current.GoToAsync($"MainPage");
        }
    }

}