using System.Windows.Input;
using Proyecto.ViewModels;

namespace Proyecto.Vistas;
public partial class Formulario : ContentPage
{


    public Formulario()
    {
        InitializeComponent();
        BindingContext = new FormularioVM();
    }


}