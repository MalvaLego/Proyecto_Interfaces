using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Entity;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Proyecto.Models;
using SQLite;

namespace Proyecto.Vistas;

public partial class ListaServicios : INotifyPropertyChanged
{
    //public ICommand borrarServicioCommand { get; set; }
    private ObservableCollection<Servicio> _servicios;
    public ObservableCollection<Servicio> Servicios
    {
        get => _servicios;
        set
        {
            _servicios = value;
            OnPropertyChanged();
        }
    }

    public event PropertyChangedEventHandler PropertyChanged;
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public ListaServicios()
	{
		InitializeComponent();
        CargarServicios();
        //borrarServicioCommand = new Command<Servicio>(EliminarServicio);
        BindingContext = this;
    }

    /*
    async void EliminarServicio(Servicio servicio)
    {
        await Shell.Current.DisplayAlert("Ok", "Dentro", "Ok");
        if (servicio != null)
        {
            bool confirmacion = await Shell.Current.DisplayAlert("Confirmar", "�Est�s seguro de eliminar este servicio?", "S�", "No");
            if (confirmacion)
            {
                string baseDirectory = AppContext.BaseDirectory;
                string databasePath = Path.Combine(baseDirectory, "DB", "ProyectoDB.db");

                using (var connection = new SQLiteConnection(databasePath))
                {
                    connection.Delete(servicio);
                }

                Servicios.Remove(servicio);

                // Mensaje de confirmaci�n
                await DisplayAlert("�xito", "El servicio ha sido eliminado", "OK");
            }
        }

        CargarServicios();
    }
    */

    async void eliminarClicked(object sender, EventArgs e)
    {
        // Obtiene el servicio seleccionado desde el BindingContext del bot�n
        var button = sender as Button;
        var servicio = button?.BindingContext as Servicio;

        if (servicio == null)
        {
            await DisplayAlert("Error", "No se pudo obtener el servicio a eliminar", "OK");
            return;
        }

        bool confirmacion = await DisplayAlert("Confirmar", "�Est�s seguro de eliminar este servicio?", "S�", "No");
        if (confirmacion)
        {
            string baseDirectory = AppContext.BaseDirectory;
            string databasePath = Path.Combine(baseDirectory, "DB", "ProyectoDB.db");

            using (var connection = new SQLiteConnection(databasePath))
            {
                connection.Delete(servicio);
            }

            Servicios.Remove(servicio);

            await DisplayAlert("�xito", "El servicio ha sido eliminado", "OK");
            CargarServicios();
        }
    }


    async void CargarServicios()
    {
        string baseDirectory = AppContext.BaseDirectory;
        string databasePath = Path.Combine(baseDirectory, "DB", "ProyectoDB.db");

        using (var connection = new SQLiteConnection(databasePath))
        {
            var servicios = connection.Table<Servicio>().ToList();
            Servicios = new ObservableCollection<Servicio>(servicios);

        }
    }
    
}