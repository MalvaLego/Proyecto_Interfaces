using System.Windows.Input;

namespace Proyecto.Vistas;

public partial class login : ContentPage
{
	ICommand irCommand { get; set; }
	public login()
	{
		InitializeComponent();
		irCommand = new Command(ir);
		BindingContext = this;
	}

	public async void ir()
	{
        string nombre = NombreEntry.Text;
        string apellidos = ApellidosEntry.Text;
        string correo = CorreoEntry.Text;
        string contrase�a = PasswordEntry.Text;
        string confirmarContrase�a = ConfirmPasswordEntry.Text;

        if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(apellidos) ||
            string.IsNullOrWhiteSpace(correo) || string.IsNullOrWhiteSpace(contrase�a))
        {
            await DisplayAlert("Error", "Todos los campos son obligatorios.", "OK");
            return;
        }

        if (contrase�a != confirmarContrase�a)
        {
            await DisplayAlert("Error", "Las contrase�as no coinciden.", "OK");
            return;
        }

        // Validar que el CheckBox est� marcado
        if (!chkTerminos.IsChecked)
        {
            await DisplayAlert("Error", "Debes aceptar los t�rminos y condiciones.", "OK");
            return;
        }

        await Shell.Current.GoToAsync($"MainPage");
	}

    private async void btnClicked(object sender, EventArgs e)
    {
        string nombre = NombreEntry.Text;
        string apellidos = ApellidosEntry.Text;
        string correo = CorreoEntry.Text;
        string contrase�a = PasswordEntry.Text;
        string confirmarContrase�a = ConfirmPasswordEntry.Text;

        if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(apellidos) ||
            string.IsNullOrWhiteSpace(correo) || string.IsNullOrWhiteSpace(contrase�a))
        {
            await DisplayAlert("Error", "Todos los campos son obligatorios.", "OK");
            return;
        }

        if (contrase�a != confirmarContrase�a)
        {
            await DisplayAlert("Error", "Las contrase�as no coinciden.", "OK");
            return;
        }

        // Validar que el CheckBox est� marcado
        if (!chkTerminos.IsChecked)
        {
            await DisplayAlert("Error", "Debes aceptar los t�rminos y condiciones.", "OK");
            return;
        }

        await Shell.Current.GoToAsync($"MainPage");
    }
}