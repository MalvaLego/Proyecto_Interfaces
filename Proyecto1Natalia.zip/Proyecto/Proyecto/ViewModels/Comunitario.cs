using System.Collections.ObjectModel;
using System.Threading;
using System.Windows.Input;

namespace Proyecto.ViewModels
{
    [QueryProperty(nameof(Tarea), "Tarea")]
    public class Comunitario : ContentPage
    {
        public ObservableCollection<TodoItem> ListaFontaneria { get; set; }
        public ObservableCollection<TodoItem> ListaElectricista { get; set; }
        public ObservableCollection<TodoItem> ListaJardineria { get; set; }
        public ObservableCollection<TodoItem> ListaCerrajeria { get; set; }
        private string _tarea;
        public string Tarea
        {
            get => _tarea;
            set
            {
                _tarea = value;    
                OnPropertyChanged();
            }
        }



        
        public ICommand GoToAddCommand { get; set; }

        public Comunitario()
        {
            Lista = new ObservableCollection<TodoItem>();

            GoToAddCommand = new Command(GoToPage3);
        }


        private async void GoToPage3()
        {
            await Shell.Current.GoToAsync(nameof(AddItemNewWindow));
        }


    }
}

