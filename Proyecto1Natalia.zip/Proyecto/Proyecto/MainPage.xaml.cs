﻿using System.Collections.ObjectModel;

namespace Proyecto
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public ObservableCollection<String> Lista { get; set; }
        private string _tarea;
        public string Tarea
        {
            get => _tarea;
            set
            {
                _tarea = value;               
                OnPropertyChanged();
            }
        }
        public MainPage()
        {
            InitializeComponent();
        }

        
    }

}
